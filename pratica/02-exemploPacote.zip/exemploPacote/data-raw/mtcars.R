## code to prepare `mtcars` dataset goes here

mtcars2 <- dplyr::as_tibble(mtcars)

usethis::use_data(mtcars2, overwrite = TRUE)

fazer_grafico_dispersao <- function(tab, x, y) {
  ggplot2::ggplot(tab) +
    ggplot2::geom_point(ggplot2::aes(x = {{x}}, y = {{y}}))
}


fazer_grafico_dispersao_texto <- function(tab, x, y) {
  ggplot2::ggplot(tab) +
    ggplot2::geom_point(ggplot2::aes(x = .data[[x]], y = .data[[y]]))
}

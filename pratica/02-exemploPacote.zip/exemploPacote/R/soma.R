
#' Soma 2 números
#'
#' @param x O primeiro número.
#' @param y O segundo número.
#'
#' @return Um número.
#' @export
#'
soma_2 <- function(x, y) {
  x + y
}

soma_geral <- function(vetor) {
  resultado <- 0
  for(valor in vetor) {
    resultado <- resultado + valor
  }
  resultado
}



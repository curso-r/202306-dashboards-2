#' The application server-side
#'
#' @param input,output,session Internal parameters for {shiny}.
#'     DO NOT REMOVE.
#' @import shiny
#' @noRd
app_server <- function(input, output, session) {
  # Your application server logic

  pnud <- readRDS(
    app_sys("pnud_min.rds")
  )

  mod_reactable_server("reactable_1", pnud)

}

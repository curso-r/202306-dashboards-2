#' reactable UI Function
#'
#' @description A shiny Module.
#'
#' @param id,input,output,session Internal parameters for {shiny}.
#'
#' @noRd
#'
#' @importFrom shiny NS tagList
mod_reactable_ui <- function(id) {
  ns <- NS(id)
  tagList(
    titlePanel("Tabelas com reactable"),
    hr(),
    fluidRow(
      bs4Dash::bs4Card(
        title = "Filtros",
        width = 12,
        fluidRow(
          column(
            width = 4,
            selectInput(
              inputId = ns("ano"),
              label = "Selecione um ano",
              choices = "",
              width = "80%"
            )
          ),
          column(
            width = 4,
            selectInput(
              inputId = ns("regiao"),
              label = "Selecione uma região",
              choices = "",
              width = "80%"
            )
          ),
          column(
            width = 4,
            selectInput(
              inputId = ns("indice"),
              label = "Selecione um índice",
              choices = pegar_indices(),
              width = "80%"
            )
          )
        )
      )
    ),
    reactable::reactableOutput(outputId = ns("reactable"))
  )
}

#' reactable Server Functions
#'
#' @noRd
mod_reactable_server <- function(id, pnud) {
  moduleServer(id, function(input, output, session) {
    ns <- session$ns

    anos <- pnud |>
      dplyr::pull(ano) |>
      unique() |>
      sort()

    updateSelectInput(
      inputId = "ano",
      choices = anos
    )

    regioes <- pnud |>
      dplyr::pull(regiao_nm) |>
      unique() |>
      sort()

    updateSelectInput(
      inputId = "regiao",
      choices = regioes
    )

    output$reactable <- reactable::renderReactable({

      pnud |>
        dplyr::filter(
          regiao_nm %in% input$regiao,
          ano == input$ano
        ) |>
        dplyr::arrange(desc(.data[[input$indice]])) |>
        dplyr::mutate(
          rank = dplyr::row_number()
        ) |>
        dplyr::select(
          "Rank" = rank,
          "Município" = muni_nm,
          "UF" = uf_sigla,
          "IDHM" = idhm,
          "Esperaça de vida" = espvida,
          "Renda" = rdpc,
          "GINI" = gini,
          "População" = pop
        ) |>
        reactable::reactable(
          defaultPageSize = 15,
          searchable = TRUE,
          striped = TRUE,
          language = reactable::reactableLang(
            searchPlaceholder = "Procurar..."
          )
        )

    })

  })
}

## To be copied in the UI
# mod_reactable_ui("reactable_1")

## To be copied in the server
# mod_reactable_server("reactable_1")

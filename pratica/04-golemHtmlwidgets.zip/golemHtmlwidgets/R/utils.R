#' Pega os possíveis indices
#'
#' @return
#' @export
#'
#' @examples
pegar_indices <- function() {
  c(
    "Indice de desenvolvimento humano" = "idhm",
    "Esperanca de vida" = "espvida",
    "Renda per capita" = "rdpc",
    "Indice de GINI" = "gini",
    "Populacao" = "pop"
  )
}
